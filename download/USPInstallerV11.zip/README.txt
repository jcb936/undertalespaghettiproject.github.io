# Installare la patch per l'ultima versione di UNDERTALE

(Trovi queste istruzioni anche qua: https://undertaleita.net/)

# Installare la patch per l'ultima versione di UNDERTALE

Ciao! 
Abbiamo aggiornato la patch (**V1.11**), e ora è compatibile con l'ultima versione di *UNDERTALE* su PC (**V1.08**). Purtroppo non abbiamo ancora avuto modo di correggere i vari errori presenti, e qualche stringa è rimasta non tradotta (per esempio alcune linee nel menu delle opzioni). Ci stiamo arrivando, sarà tutto sistemato nella prossima release.


## Prerequisiti

- Come prima cosa, trovate la cartella dove avete installato *UNDERTALE*; generalmente, se avete installato il gioco tramite Steam, questa sarà:
```
C:\Programmi(x86)\Steam\steamapps\common\Undertale
```
- Verificate se il vostro sistema è a 32Bit o 64Bit, potete farlo andando su Informazioni sul Sistema dalla barra di ricerca di Windows in basso a sinistra.
- Installate il runtime di .NET 5.0 da qua: https://dotnet.microsoft.com/download/dotnet/5.0/runtime, selezionando *Download x64* o *Download x86* sotto *Run console apps*, a seconda se avete rispettivamente un sistema a 64 o 32 bit.
## Installazione
- Scaricate il file .zip con l'installer dal sito https://undertaleita.net/
- Decomprimete il contenuto del file nella cartella in cui avete installato *UNDERTALE*.
- Assicuratevi che ora la cartella includa questi tre file:
	- *data.win* (dall'installazione del gioco)
	- *UndertaleItaInstaller_x86.exe* (dallo zip dell'installer)
	- *UndertaleItaInstaller_x64.exe* (dallo zip dell'installer)
- Avviate ***UndertaleItaInstaller_x86.exe*** se avete un sistema a 32Bit, o ***UndertaleItaInstaller_x64.exe*** su un sistema a 64Bit, e aspettate che l'installazione sia conclusa.
- Tutto fatto! Potete ora avviare il gioco e sarà in italiano!

**NOTA**: Se quando provate ad avviare l'exe Windows vi blocca con un popup di Windows SmartScreen, cliccate su *Ulteriori Informazioni*, e poi su *Esegui comunque*.

## Note aggiuntive 
L'aggiornamento della patch è stato possibile grazie ai nuovi membri del team [@Nik](https://github.com/nkrapivin), [@Depa](https://www.youtube.com/c/depa31/) e @GiMoody, sentirete ancora parlare di loro. In più, un grazie speciale a [@krzys_h](https://github.com/krzys-h) per aver sviluppato *UndertaleModTool*, che è stato essenziale per lo sviluppo.

Come già accennato, aggiorneremo e sistemeremo gli errori della patch con la prossima release. La priorita', per adesso, è sulla traduzione del Capitolo 2 di *DELTARUNE*. Approfitteremo della release anche per aggiornare il sito, che ha bisogno di una svecchiata.
Nel frattempo, potete seguire tutti gli aggiornamenti sulla pagina Facebook.

A presto!

*Renard*